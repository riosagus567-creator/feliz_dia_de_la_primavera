document.addEventListener('DOMContentLoaded', () => {
    const audioPlayer = document.getElementById('audio-player');
    const musicButton = document.getElementById('music-button');

    audioPlayer.play().catch(error => {
        console.log('Autoplay fue bloqueado. El usuario debe interactuar para reproducir el audio.');
    });

    musicButton.addEventListener('click', () => {
        if (audioPlayer.paused) {
            audioPlayer.play();
            musicButton.textContent = '🎵';
        } else {
            audioPlayer.pause();
            musicButton.textContent = '🔇';
        }
    });
});
